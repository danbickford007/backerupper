# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
War::Application.config.secret_key_base = '1effb802fc4f94182389840fa048f6d2618e55eebf7938a1f0ec4d0ab05de640e981e3f8e42f87e604fcd5496562a602517585e9428bc337d881c6c2c483c658'
