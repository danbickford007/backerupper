class Game < ActiveRecord::Base
end
