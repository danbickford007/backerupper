class Location

  def initialize
    @pwd = `pwd`
  end

  def creds
    p "Please enter your git password"
    @password  = gets 
    Clone.new(@pwd, @password)
  end

end
