# Be sure to restart your server when you modify this file.

War::Application.config.session_store :cookie_store, key: '_war_session'
